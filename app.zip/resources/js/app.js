import './bootstrap';
document.addEventListener("DOMContentLoaded", () => {
    console.log("Login cargado correctamente ✅");
});
